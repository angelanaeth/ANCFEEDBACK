module.exports = {
  apps: [
    {
      name: 'angela-coach',
      script: 'npx',
      args: 'wrangler pages dev dist --d1=DB:angela-db --local --ip 0.0.0.0 --port 5000',
      env: {
        NODE_ENV: 'development',
        PORT: 5000
      },
      watch: false,
      instances: 1,
      exec_mode: 'fork',
      autorestart: true,
      max_restarts: 10,
      min_uptime: '10s'
    }
  ]
}
