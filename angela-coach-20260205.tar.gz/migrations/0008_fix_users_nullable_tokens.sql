-- Fix users table to allow NULL tokens for athletes managed by coach
-- In coach mode, athletes don't have their own access tokens
-- Only the coach account needs tokens

-- SQLite doesn't support ALTER COLUMN, so we need to recreate the table
-- Step 1: Create new table with nullable token fields
CREATE TABLE IF NOT EXISTS users_new (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  tp_athlete_id TEXT UNIQUE NOT NULL,
  email TEXT,
  name TEXT NOT NULL,
  access_token TEXT,  -- Changed to nullable
  refresh_token TEXT,  -- Changed to nullable
  token_expires_at INTEGER,  -- Changed to nullable
  account_type TEXT DEFAULT 'athlete',
  bio TEXT,
  location TEXT,
  coach_id INTEGER,
  coach_email TEXT,
  coach_name TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (coach_id) REFERENCES users(id)
);

-- Step 2: Copy data from old table
INSERT INTO users_new SELECT * FROM users;

-- Step 3: Drop old table
DROP TABLE users;

-- Step 4: Rename new table
ALTER TABLE users_new RENAME TO users;

-- Step 5: Recreate indexes
CREATE INDEX IF NOT EXISTS idx_users_tp_athlete_id ON users(tp_athlete_id);
CREATE INDEX IF NOT EXISTS idx_users_account_type ON users(account_type);
CREATE INDEX IF NOT EXISTS idx_users_coach_id ON users(coach_id);
