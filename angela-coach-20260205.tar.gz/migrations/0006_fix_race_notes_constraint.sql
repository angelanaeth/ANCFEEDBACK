-- Fix UNIQUE constraint for race notes to allow multiple plans per athlete
-- SQLite requires recreating the table to modify constraints

-- Create new table without the problematic UNIQUE constraint
CREATE TABLE IF NOT EXISTS athlete_notes_new (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  note_text TEXT NOT NULL,
  note_type TEXT DEFAULT 'general',
  created_by INTEGER,
  race_name TEXT,
  content TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id),
  FOREIGN KEY (created_by) REFERENCES users(id)
  -- NOTE: Removed UNIQUE(user_id, created_by) to allow multiple race plans
);

-- Copy data from old table
INSERT INTO athlete_notes_new 
SELECT id, user_id, note_text, note_type, created_by, race_name, content, created_at, updated_at 
FROM athlete_notes;

-- Drop old table
DROP TABLE athlete_notes;

-- Rename new table
ALTER TABLE athlete_notes_new RENAME TO athlete_notes;

-- Recreate indexes
CREATE INDEX IF NOT EXISTS idx_athlete_notes_race_type ON athlete_notes(user_id, note_type);
CREATE INDEX IF NOT EXISTS idx_athlete_notes_race_name ON athlete_notes(user_id, race_name);
